# -*- coding: utf-8 -*-

from . import orchard
from . import inherit_res_partner
from . import inherit_purchase_order
