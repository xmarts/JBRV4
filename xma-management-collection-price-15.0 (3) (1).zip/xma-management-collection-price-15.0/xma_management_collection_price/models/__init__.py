# -*- coding: utf-8 -*-

from . import inherit_mrp_production
from . import collection_price
from . import inherit_product_category
