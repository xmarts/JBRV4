# -*- coding: utf-8 -*-
from odoo import models, fields, api
from datetime import datetime, timedelta, date
import logging

_logger = logging.getLogger(__name__)

class MrpProduction(models.Model):
    _inherit = "mrp.production"

    lot_id = fields.Many2one(
        "stock.production.lot",
        string="Lote de producto aguacate",
        compute="_search_lot"
    )
    lot_name = fields.Char(
        string="Lote",
        related="lot_id.name",
        store=True
    )
    collec_price = fields.Float(
        string="Acopio",
        compute="_get_collection_price",
        store=True
    )
    manage_price = fields.Float(
        string="Gerencia",
        compute="_get_collection_price",
        store=True
    )
    qty_line = fields.Float(
        string="Por consumir",
        compute="_search_lot",
        store=True
    )
    percentage = fields.Float(
        string="Porcentaje",
        compute="_get_percentage",
        store=True,
        digits=(12, 2)
    )

    @api.depends(
        "product_id.categ_id.collection_price_ids", 
        "product_id.categ_id.collection_price_ids.name",
        "product_id.categ_id.collection_price_ids.collection_price",
        "product_id.categ_id.collection_price_ids.management_price")
    def _get_collection_price(self):
        for rec in self:
            if rec.product_id:
                if rec.product_id.categ_id.collection_price_ids:
                    today = fields.Date.today()
                    for r in rec.product_id.categ_id.collection_price_ids:
                        if today == r.name:
                            rec.collec_price = r.collection_price
                            rec.manage_price = r.management_price
                        else:
                            rec.collec_price = None
                            rec.manage_price = None
                else:
                    rec.collec_price = None
                    rec.manage_price = None
            else:
                rec.collec_price = None
                rec.manage_price = None
    
    def _search_lot(self):
        for rec in self:
            raw_hass = rec.move_raw_ids.filtered(lambda x: "MX HASS" in x.product_id.name.upper())
            _logger.warning("raw_omveeee\n\n" + str(raw_hass.product_id.name))
            if raw_hass:
                hass_lot = raw_hass.move_line_ids.lot_id
                _logger.warning("loteeeeee\n\n" + str(hass_lot.name))
                if hass_lot:
                    rec.lot_id = hass_lot.id
                    rec.qty_line = raw_hass.product_uom_qty
                else:
                    rec.lot_id = False
                    rec.qty_line = False
            else:
                rec.lot_id = False
                rec.qty_line = False
    
    def _get_percentage(self):
        for rec in self:
            if rec.lot_id:
                rec.percentage = (rec.qty_line * 100) / (rec.lot_id.product_qty)
            else:
                rec.percentage = False